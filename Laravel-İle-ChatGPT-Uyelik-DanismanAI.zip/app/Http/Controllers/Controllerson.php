<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Models\User;
use App\Models\destek;

class Controllerson extends Controller
{
    
function kayit(Request $Request){

   $ren = new User;

   $ren->name = $Request->name;
   $ren->email = $Request->email;
   $ren->password = $Request->password;

   $ren->save();

   return redirect('ticket')->with('status','Uye girisi yapabilirsiniz');

}

function giris(Request $request): RedirectResponse

{

	$credentials = $request->validate([
            'email' => ['required', 'email'],
            'password' => ['required'],
        ]);
 
        if (Auth::attempt($credentials)) {
            $request->session()->regenerate();
 
            return redirect()->intended('dashboard');
        }
 
     

        return redirect('ticket')->with('status','yanlıs email veya sifre');
}


function logout(Request $request)
{
    Auth::logout();
 
    $request->session()->invalidate();
 
    $request->session()->regenerateToken();
 
    return redirect('cikis');
}


function ticketac(Request $Request){

   $ren = new destek;

   $ren->name = $Request->name;
   $ren->email = $Request->email;
   $ren->yorum = $Request->yorum;

   $ren->save();

   return redirect('dashboard')->with('status','gonderildi');

}


function veri($email){

  $can = destek::select('name','email','yorum')->where('email','=',$email)->get();

  return view("kayitlarim",compact('can'));

}

function danisman(Request $Request) {

$sor = $Request->input('sor');
$curl = curl_init();

curl_setopt_array($curl, array(
  CURLOPT_URL => 'https://api.openai.com/v1/completions',
  CURLOPT_RETURNTRANSFER => true,
  CURLOPT_ENCODING => '',
  CURLOPT_MAXREDIRS => 10,
  CURLOPT_TIMEOUT => 0,
  CURLOPT_FOLLOWLOCATION => true,
  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
  CURLOPT_CUSTOMREQUEST => 'POST',
  CURLOPT_POSTFIELDS =>'{
"model": "gpt-3.5-turbo", 
"prompt": "'.$sor.'", 
"temperature": 0.7, 
"max_tokens": 400
}',
  CURLOPT_HTTPHEADER => array(
    'Content-Type: application/json',
    'Authorization: Bearer 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'
  ),
));

$response = curl_exec($curl);

curl_close($curl);

echo $response;

return view("danismanai",compact('response'));
}




}
