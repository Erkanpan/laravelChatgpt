<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body background="tan.JPG">
	<br><br><br>Çıkış Yaptınız.
<center>
	<button type="button" class="btn btn-primary"><a href="{{url('/')}}"><p style="color: #ffffff">  Ana Sayfa</p></a></button> 
     <button type="button" class="btn btn-primary"><a href="{{route('ticket')}}"><p style="color: #ffffff"> Ticket Aç</p></a></button>

	 </center>
</body>
</html>