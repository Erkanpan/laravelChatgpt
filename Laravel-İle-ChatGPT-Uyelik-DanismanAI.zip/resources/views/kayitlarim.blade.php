<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body background="tan.JPG">
	<br><br><br>
<center>
	<button type="button" class="btn btn-primary"><a href="{{url('/dashboard')}}"><p style="color: #ffffff">Ticket Aç</p></a></button> 
	
		<button type="button" class="btn btn-primary"><a href="{{route('kayitlarim',Auth::user()->email)}}"><p style="color: #ffffff">  Destek Kayıtlarım</p></a></button> 
		<button type="button" class="btn btn-primary"><a href="{{route('danismanai')}}"><p style="color: #ffffff">  Danışman AI</p></a></button> 

     <button type="button" class="btn btn-primary"><a href="{{route('logout')}}"><p style="color: #ffffff"> Çıkış</p></a></button>

	 <center> {{session('status')}}</center>
	 <br>
	 <?php
	 $user = Auth::user();

	 $obj = json_decode($user);
	 $isim = $obj->{'name'};
	  $email = $obj->{'email'};
	 ?>
	 <br><br>

	 Destek Kayıtlarım<br>
<table>

	 @foreach ($can as $ver)
<tr>
	<td>{{ $ver->name }}</td>
	<td>{{ $ver->email }}</td>
	<td>{{ $ver->yorum }}</td>
</tr>


	@endForeach


</table>
	 
	 <br><br>
	
	 </center>
</body>
</html>