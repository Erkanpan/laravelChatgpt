<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body background="tan.JPG">
	<br><br><br>
<center>
	<button type="button" class="btn btn-primary"><a href="{{url('/')}}"><p style="color: #ffffff">  Ana Sayfa</p></a></button> 
     <button type="button" class="btn btn-primary"><a href="{{route('ticket')}}"><p style="color: #ffffff"> Ticket Aç</p></a></button>

	 
	 <br><br>

	 UYE OL<br>
	 <form method="post" action="{{route('kayit')}}">
	 	@csrf
	Name: <input type="text" name="name"><br><br>
    Email: <input type="email" name="email"><br><br>
    Şifre: <input type="password" name="password"><br><br>
     <input type="submit" value="Kayit">
	 </form>
	 <br><br>
	 <a href="{{url('ticket')}}">Kayit</a>
	 </center>
</body>
</html>