<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\Controllerson;



Route::get('/', function () {
    return view('index');
})->name('anasayfa');


Route::get('/ticket', function () {
    return view('ticket');
})->name('ticket');

Route::get('/uyeol', function () {
    return view('uyeol');
});

Route::post('uyeol',[Controllerson::class,'kayit'])->name('kayit');

Route::post('ticket',[Controllerson::class,'giris'])->name('giris');



//dashboard

Route::get('/dashboard', function () {
    return view('dashboard');
})->middleware('auth');


Route::get('cikis',[Controllerson::class,'logout'])->name('logout')->middleware('auth');

Route::post('dashboard',[Controllerson::class,'ticketac'])->name('ticketac')->middleware('auth');

Route::get('kayitlarim/{email}',[Controllerson::class,'veri'])->name('kayitlarim')->middleware('auth');


Route::get('/danismanai', function () {
    return view('danismanai');
})->name('danismanai')->middleware('auth');

Route::post('danismanai',[Controllerson::class,'danisman'])->name('danisman')->middleware('auth');

//çıkıs sayfası
