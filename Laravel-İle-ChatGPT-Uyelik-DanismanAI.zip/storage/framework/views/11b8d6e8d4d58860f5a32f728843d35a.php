<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
Çıkış yaptınız
</body>
</html><?php /**PATH C:\laragon\www\ticket\resources\views/cikis.blade.php ENDPATH**/ ?>