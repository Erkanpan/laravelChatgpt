<html>
<head>
	<title></title>
	<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
</head>
<body background="tan.JPG">
	<br><br><br>
<center>
	<button type="button" class="btn btn-primary"><a href="<?php echo e(url('/dashboard')); ?>"><p style="color: #ffffff">Ticket Aç</p></a></button> 
	
		<button type="button" class="btn btn-primary"><a href="<?php echo e(route('kayitlarim',Auth::user()->email)); ?>"><p style="color: #ffffff">  Destek Kayıtlarım</p></a></button> 

		<button type="button" class="btn btn-primary"><a href="<?php echo e(route('danismanai')); ?>"><p style="color: #ffffff">  Danışman AI</p></a></button> 

     <button type="button" class="btn btn-primary"><a href="<?php echo e(route('logout')); ?>"><p style="color: #ffffff"> Çıkış</p></a></button>

	 <center><?php echo e(session('status')); ?> </center>
	 <br>
	 <?php
	 $user = Auth::user();

	 $obj = json_decode($user);
	 $isim = $obj->{'name'};
	  $email = $obj->{'email'};
	 ?>
	 <br><br>

	 Danişman AI<br>
	 <form method="post" action="<?php echo e(route('danisman')); ?>">
	 	<?php echo csrf_field(); ?>
	 <input type="hidden" name="name" value="<?php echo $isim; ?>" readonly=""><br><br>
    <input type="hidden" name="email" value="<?php echo $email; ?>" readonly=""><br><br>
    Sorunuz: <input type="text" name="sor"><br><br>

     <input type="submit" value="Gonder">
	 </form>


	 <br><br>
	
	 </center>
	
</body>
</html><?php /**PATH C:\laragon\www\ticket\resources\views/danismanai.blade.php ENDPATH**/ ?>